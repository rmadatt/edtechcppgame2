import {
  QUESTIONS,
  QUESTIONS_PER_STAGE,
  type Difficulty,
  type Question,
} from "../data/questions";
import { mulberry32, shuffle } from "../lib/rng";

export interface Option {
  text: string;
  correct: boolean;
}

/** Build the ordered question deck for a stage. */
export function buildDeck(stage: number, seed: number): Question[] {
  const rng = mulberry32((seed + stage * 7919 + 17) >>> 0);
  const maxTier = Math.min(8, stage + 1);
  const eligible = QUESTIONS.filter((q) => q.tier <= maxTier);
  const normals = shuffle(
    eligible.filter((q) => !q.boss),
    rng,
  );
  const bosses = shuffle(
    eligible.filter((q) => q.boss),
    rng,
  );
  const wantsBoss = bosses.length > 0 ? 1 : 0;
  const deck = normals.slice(0, QUESTIONS_PER_STAGE - wantsBoss);
  if (wantsBoss) {
    const slot = Math.min(deck.length, 4 + Math.floor(rng() * 2));
    deck.splice(slot, 0, bosses[0]);
  }
  return deck;
}

/** Shuffle the answer options while remembering which one is correct. */
export function optionsFor(q: Question, rng: () => number): Option[] {
  return shuffle(
    q.options.map((text, i) => ({ text, correct: i === q.answer })),
    rng,
  );
}

export function timeLimitFor(stage: number, diff: Difficulty, boss?: boolean): number {
  const base = Math.max(diff.minTime, diff.timeLimit - (stage - 1) * diff.timeDecay);
  return boss ? Math.min(diff.timeLimit * 1.4, base * 1.25 + 1) : base;
}

export function multiplierFor(combo: number): number {
  return Math.min(5, 1 + Math.floor(combo / 3));
}

export function pointsFor(
  boss: boolean | undefined,
  combo: number,
  timeLeft: number,
  timeLimit: number,
  diff: Difficulty,
): number {
  const base = (boss ? 220 : 100) * diff.scoreMul;
  const speedBonus = Math.round((Math.max(0, timeLeft) / Math.max(0.001, timeLimit)) * 60);
  const mult = multiplierFor(combo);
  return Math.round((base + speedBonus) * mult);
}
