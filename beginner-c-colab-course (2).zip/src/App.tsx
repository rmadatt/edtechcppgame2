import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CodePanel } from "./components/CodePanel";
import { FxCanvas, type FxHandle } from "./components/FxCanvas";
import { GameOverScreen } from "./components/GameOverScreen";
import { Hud } from "./components/Hud";
import { Leaderboard } from "./components/Leaderboard";
import { MenuScreen } from "./components/MenuScreen";
import { Modal } from "./components/Modal";
import { OptionGrid } from "./components/OptionGrid";
import { PauseOverlay, StageClearOverlay } from "./components/Overlays";
import { Runner } from "./components/Runner";
import { DIFFICULTIES, type Difficulty, type Question } from "./data/questions";
import { buildDeck, multiplierFor, optionsFor, pointsFor, timeLimitFor, type Option } from "./game/engine";
import { play, setMuted, unlockAudio } from "./lib/audio";
import { mulberry32 } from "./lib/rng";
import { loadScores, saveScore, type ScoreEntry } from "./lib/storage";

type Screen = "menu" | "playing" | "paused" | "stage" | "gameover";

interface RunState {
  score: number;
  lives: number;
  combo: number;
  bestCombo: number;
  stage: number;
  qIndex: number;
  deck: Question[];
  question: Question;
  options: Option[];
  phase: "asking" | "reveal";
  result: "correct" | "wrong" | null;
  picked: number | null;
  timeLeft: number;
  timeLimit: number;
  correctCount: number;
  totalCount: number;
  lastPoints: number;
  seed: number;
}

interface Floater {
  id: string;
  x: number;
  y: number;
  text: string;
  sub: string;
  color: string;
}

function createRun(diff: Difficulty, seed: number): RunState {
  const deck = buildDeck(1, seed);
  const rng = mulberry32((seed + 991) >>> 0);
  const question = deck[0];
  const options = optionsFor(question, rng);
  const timeLimit = timeLimitFor(1, diff, question.boss);
  return {
    score: 0,
    lives: diff.lives,
    combo: 0,
    bestCombo: 0,
    stage: 1,
    qIndex: 0,
    deck,
    question,
    options,
    phase: "asking",
    result: null,
    picked: null,
    timeLeft: timeLimit,
    timeLimit,
    correctCount: 0,
    totalCount: 0,
    lastPoints: 0,
    seed,
  };
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [difficulty, setDifficulty] = useState<Difficulty>(DIFFICULTIES[1]);
  const [muted, setMutedState] = useState(false);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [run, setRun] = useState<RunState>(() => createRun(DIFFICULTIES[1], 12345));
  const [selected, setSelected] = useState(0);
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [banner, setBanner] = useState<{ id: number; text: string; color: string } | null>(null);
  const [runnerMood, setRunnerMood] = useState<"idle" | "happy" | "oops">("idle");
  const [stageBonus, setStageBonus] = useState(0);
  const [showBoard, setShowBoard] = useState(false);

  const runRef = useRef(run);
  const screenRef = useRef(screen);
  const diffRef = useRef(difficulty);
  const fxRef = useRef<FxHandle | null>(null);
  const timerBarRef = useRef<HTMLDivElement | null>(null);
  const shakeElRef = useRef<HTMLDivElement | null>(null);
  const shakeRef = useRef(0);
  const optionEls = useRef<(HTMLButtonElement | null)[]>([]);
  const advanceTimer = useRef<number | null>(null);
  const advanceDeadline = useRef(0);
  const advanceLeft = useRef(0);
  const tickRef = useRef(-1);
  const api = useRef<Record<string, (arg?: unknown) => void>>({});

  useEffect(() => {
    screenRef.current = screen;
  }, [screen]);

  useEffect(() => {
    diffRef.current = difficulty;
  }, [difficulty]);

  const update = useCallback((fn: (r: RunState) => RunState) => {
    const next = fn(runRef.current);
    runRef.current = next;
    setRun(next);
  }, []);

  const shake = useCallback((amount: number) => {
    shakeRef.current = Math.max(shakeRef.current, amount);
  }, []);

  const addFloater = useCallback((x: number, y: number, text: string, sub: string, color: string) => {
    const id = Math.random().toString(36).slice(2);
    setFloaters((f) => [...f.slice(-6), { id, x, y, text, sub, color }]);
    window.setTimeout(() => {
      setFloaters((f) => f.filter((x2) => x2.id !== id));
    }, 1000);
  }, []);

  const showBanner = useCallback((text: string, color: string) => {
    setBanner({ id: Date.now(), text, color });
    window.setTimeout(() => setBanner(null), 1000);
  }, []);

  /* ------------------------------------------------------------------ */
  /* game flow                                                           */
  /* ------------------------------------------------------------------ */

  const startRun = useCallback(
    (diff?: Difficulty) => {
      const d = diff ?? diffRef.current;
      unlockAudio();
      play("start");
      const seed = (Date.now() ^ (Math.random() * 0xffffffff)) >>> 0;
      const fresh = createRun(d, seed);
      runRef.current = fresh;
      setRun(fresh);
      setSelected(0);
      setRunnerMood("idle");
      fxRef.current?.clear();
      screenRef.current = "playing";
      setScreen("playing");
    },
    [],
  );

  const endRun = useCallback(() => {
    if (advanceTimer.current) window.clearTimeout(advanceTimer.current);
    play("gameover");
    shake(22);
    fxRef.current?.wave("#fb7185");
    fxRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.45, "#fb7185", {
      count: 40,
      power: 460,
      square: true,
    });
    screenRef.current = "gameover";
    setScreen("gameover");
  }, [shake]);

  const clearStage = useCallback(() => {
    const r = runRef.current;
    const bonus = Math.round(300 * r.stage * diffRef.current.scoreMul);
    update((prev) => ({ ...prev, score: prev.score + bonus }));
    setStageBonus(bonus);
    play("stage");
    fxRef.current?.wave("#34d399");
    fxRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.42, "#34d399", {
      count: 46,
      power: 520,
    });
    showBanner(`BUILD OK +${bonus}`, "#34d399");
    screenRef.current = "stage";
    setScreen("stage");
  }, [showBanner, update]);

  const nextStage = useCallback(() => {
    const r = runRef.current;
    const stage = r.stage + 1;
    const deck = buildDeck(stage, r.seed);
    const rng = mulberry32((r.seed + stage * 7919 + 17) >>> 0);
    const question = deck[0];
    const options = optionsFor(question, rng);
    const timeLimit = timeLimitFor(stage, diffRef.current, question.boss);
    const next: RunState = {
      ...r,
      stage,
      deck,
      qIndex: 0,
      question,
      options,
      phase: "asking",
      result: null,
      picked: null,
      timeLimit,
      timeLeft: timeLimit,
      lives: Math.min(diffRef.current.lives, r.lives + 1),
    };
    runRef.current = next;
    setRun(next);
    setSelected(0);
    screenRef.current = "playing";
    setScreen("playing");
    showBanner(`STAGE ${stage}`, "#22d3ee");
  }, [showBanner]);

  const advance = useCallback(() => {
    const r = runRef.current;
    if (r.lives <= 0) {
      endRun();
      return;
    }
    if (r.qIndex + 1 >= r.deck.length) {
      clearStage();
      return;
    }
    update((prev) => {
      const qIndex = prev.qIndex + 1;
      const question = prev.deck[qIndex];
      const rng = mulberry32((prev.seed + qIndex * 104729) >>> 0);
      const options = optionsFor(question, rng);
      const timeLimit = timeLimitFor(prev.stage, diffRef.current, question.boss);
      return {
        ...prev,
        qIndex,
        question,
        options,
        phase: "asking",
        result: null,
        picked: null,
        timeLimit,
        timeLeft: timeLimit,
      };
    });
    setSelected(0);
  }, [clearStage, endRun, update]);

  const answer = useCallback(
    (index: number, rect?: DOMRect | null) => {
      const r = runRef.current;
      if (screenRef.current !== "playing" || r.phase !== "asking") return;
      const opt = r.options[index];
      if (!opt) return;
      const correct = opt.correct;
      const newCombo = correct ? r.combo + 1 : 0;
      const mult = multiplierFor(newCombo);
      const pts = correct
        ? pointsFor(r.question.boss, newCombo, r.timeLeft, r.timeLimit, diffRef.current)
        : 0;

      const el = rect ?? optionEls.current[index]?.getBoundingClientRect() ?? null;
      const cx = el ? el.left + el.width / 2 : window.innerWidth / 2;
      const cy = el ? el.top + el.height / 2 : window.innerHeight * 0.5;
      const fx = fxRef.current;

      if (correct) {
        fx?.burst(cx, cy, "#34d399", { count: 28, power: 360 });
        fx?.burst(cx, cy, "#fbbf24", { count: 14, power: 220, square: true });
        fx?.ring(cx, cy, "#34d399", 160);
        play("correct", newCombo);
        if (newCombo >= 3) play("combo", newCombo);
        shake(5);
        addFloater(cx, cy - 8, `+${pts}`, mult > 1 ? `x${mult}` : "", "#fbbf24");
        if (newCombo === 3 || newCombo === 6 || newCombo === 10) {
          showBanner(`COMBO x${mult}!`, "#f472b6");
        } else if (r.timeLeft / r.timeLimit > 0.72) {
          showBanner("SPEED BONUS", "#22d3ee");
        }
      } else {
        fx?.burst(cx, cy, "#fb7185", { count: 26, power: 320, square: true });
        fx?.ring(cx, cy, "#fb7185", 140);
        play("wrong");
        shake(16);
        addFloater(cx, cy - 8, "WRONG", "", "#fb7185");
      }

      update((prev) => ({
        ...prev,
        phase: "reveal",
        result: correct ? "correct" : "wrong",
        picked: index,
        combo: newCombo,
        bestCombo: Math.max(prev.bestCombo, newCombo),
        score: prev.score + pts,
        lives: correct ? prev.lives : prev.lives - 1,
        lastPoints: pts,
        totalCount: prev.totalCount + 1,
        correctCount: prev.correctCount + (correct ? 1 : 0),
      }));

      setRunnerMood(correct ? "happy" : "oops");
      window.setTimeout(() => setRunnerMood("idle"), 620);

      if (advanceTimer.current) window.clearTimeout(advanceTimer.current);
      const delay = correct ? 900 : 1350;
      advanceDeadline.current = Date.now() + delay;
      advanceTimer.current = window.setTimeout(advance, delay);
    },
    [advance, addFloater, shake, showBanner, update],
  );

  const timeoutAnswer = useCallback(() => {
    const r = runRef.current;
    if (screenRef.current !== "playing" || r.phase !== "asking") return;
    play("wrong");
    shake(18);
    fxRef.current?.burst(window.innerWidth / 2, window.innerHeight * 0.4, "#fb7185", {
      count: 30,
      power: 380,
      square: true,
    });
    fxRef.current?.ring(window.innerWidth / 2, window.innerHeight * 0.4, "#fb7185", 190);
    addFloater(window.innerWidth / 2, window.innerHeight * 0.36, "TIME OUT", "", "#fb7185");
    update((prev) => ({
      ...prev,
      phase: "reveal",
      result: "wrong",
      picked: null,
      combo: 0,
      lives: prev.lives - 1,
      totalCount: prev.totalCount + 1,
    }));
    setRunnerMood("oops");
    window.setTimeout(() => setRunnerMood("idle"), 620);
    if (advanceTimer.current) window.clearTimeout(advanceTimer.current);
    advanceDeadline.current = Date.now() + 1400;
    advanceTimer.current = window.setTimeout(advance, 1400);
  }, [addFloater, advance, shake, update]);

  const pauseGame = useCallback(() => {
    if (screenRef.current !== "playing") return;
    if (advanceTimer.current) {
      window.clearTimeout(advanceTimer.current);
      advanceTimer.current = null;
      advanceLeft.current = Math.max(0, advanceDeadline.current - Date.now());
    }
    screenRef.current = "paused";
    setScreen("paused");
  }, []);

  const resumeGame = useCallback(() => {
    if (screenRef.current !== "paused") return;
    screenRef.current = "playing";
    setScreen("playing");
    if (advanceLeft.current > 0) {
      advanceTimer.current = window.setTimeout(advance, advanceLeft.current);
      advanceLeft.current = 0;
    }
  }, [advance]);

  const goMenu = useCallback(() => {
    if (advanceTimer.current) window.clearTimeout(advanceTimer.current);
    screenRef.current = "menu";
    setScreen("menu");
  }, []);

  const toggleMute = useCallback(() => {
    setMutedState((m) => {
      const next = !m;
      setMuted(next);
      if (!next) play("select");
      return next;
    });
  }, []);

  const handleSave = useCallback(
    (name: string) => {
      const r = runRef.current;
      const next = saveScore({
        name,
        score: r.score,
        stage: r.stage,
        bestCombo: r.bestCombo,
        correct: r.correctCount,
        total: r.totalCount,
      });
      setScores(next);
    },
    [],
  );

  /* ------------------------------------------------------------------ */
  /* keyboard + pointer input                                            */
  /* ------------------------------------------------------------------ */

  api.current = {
    start: () => startRun(),
    retry: () => startRun(),
    pause: () => pauseGame(),
    resume: () => resumeGame(),
    menu: () => goMenu(),
    continueStage: () => nextStage(),
    toggleMute: () => toggleMute(),
    pick: (i) => {
      const idx = Number(i);
      if (Number.isNaN(idx) || idx < 0 || idx > 3) return;
      answer(idx);
    },
    move: (d) => {
      setSelected((s) => (s + Number(d) + 4) % 4);
      play("tick");
    },
    confirm: () => answer(selected),
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing =
        target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
      const a = api.current;
      const key = e.key;
      const lower = key.toLowerCase();

      if (lower === "m" && !typing) {
        a.toggleMute();
        return;
      }

      if (typing) return;

      const sc = screenRef.current;
      if (sc === "menu") {
        if (key === "Enter" || key === " ") {
          e.preventDefault();
          a.start();
        }
        return;
      }
      if (sc === "playing") {
        if (key >= "1" && key <= "4") {
          e.preventDefault();
          a.pick(Number(key) - 1);
          return;
        }
        if (lower >= "a" && lower <= "d") {
          e.preventDefault();
          a.pick(lower.charCodeAt(0) - 97);
          return;
        }
        if (key === "ArrowRight" || key === "ArrowDown") {
          e.preventDefault();
          a.move(1);
          return;
        }
        if (key === "ArrowLeft" || key === "ArrowUp") {
          e.preventDefault();
          a.move(-1);
          return;
        }
        if (key === "Enter" || key === " ") {
          e.preventDefault();
          a.confirm();
          return;
        }
        if (lower === "p" || key === "Escape") {
          e.preventDefault();
          a.pause();
        }
        return;
      }
      if (sc === "paused") {
        if (lower === "p" || key === "Escape" || key === "Enter") {
          e.preventDefault();
          a.resume();
        } else if (lower === "r") {
          e.preventDefault();
          a.retry();
        } else if (lower === "q") {
          e.preventDefault();
          a.menu();
        }
        return;
      }
      if (sc === "stage") {
        if (key === "Enter" || key === " ") {
          e.preventDefault();
          a.continueStage();
        }
        return;
      }
      if (sc === "gameover") {
        if (lower === "r") {
          e.preventDefault();
          a.retry();
        } else if (key === "Escape") {
          e.preventDefault();
          a.menu();
        }
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  /* ------------------------------------------------------------------ */
  /* animation loop: timer bar + screen shake                            */
  /* ------------------------------------------------------------------ */

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      const el = shakeElRef.current;
      if (el) {
        if (shakeRef.current > 0.05) {
          shakeRef.current *= Math.pow(0.0008, dt);
          const a = shakeRef.current;
          el.style.transform = `translate3d(${(Math.random() * 2 - 1) * a}px, ${
            (Math.random() * 2 - 1) * a * 0.6
          }px, 0)`;
        } else if (shakeRef.current !== 0) {
          shakeRef.current = 0;
          el.style.transform = "";
        }
      }

      const r = runRef.current;
      if (screenRef.current === "playing" && r.phase === "asking") {
        r.timeLeft -= dt;
        const frac = Math.max(0, r.timeLeft / r.timeLimit);
        const bar = timerBarRef.current;
        if (bar) {
          bar.style.width = `${frac * 100}%`;
          const color = frac > 0.5 ? "#34d399" : frac > 0.22 ? "#fbbf24" : "#fb7185";
          bar.style.background = color;
          bar.style.boxShadow = `0 0 ${8 + (1 - frac) * 26}px -2px ${color}`;
          bar.style.opacity =
            frac < 0.2 ? String(0.55 + 0.45 * Math.abs(Math.sin(now / 110))) : "1";
        }
        if (r.timeLeft <= 0) {
          r.timeLeft = 0;
          timeoutAnswer();
        } else {
          const secs = Math.ceil(r.timeLeft);
          if (secs <= 3 && secs !== tickRef.current) {
            tickRef.current = secs;
            play("countdown");
          } else if (secs > 3) {
            tickRef.current = -1;
          }
        }
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [timeoutAnswer]);

  useEffect(() => {
    return () => {
      if (advanceTimer.current) window.clearTimeout(advanceTimer.current);
    };
  }, []);

  /* ------------------------------------------------------------------ */
  /* render                                                              */
  /* ------------------------------------------------------------------ */

  const multiplier = multiplierFor(run.combo);
  const progress = ((run.qIndex + (run.phase === "reveal" ? 1 : 0)) / run.deck.length) * 100;
  const bestBefore = scores.length ? scores[0].score : 0;
  const isBest = run.score > bestBefore;

  const registerOption = useCallback((i: number, el: HTMLButtonElement | null) => {
    optionEls.current[i] = el;
  }, []);

  const hint = useMemo(
    () =>
      screen === "playing"
        ? "press 1–4 or tap a card"
        : "press enter to build",
    [screen],
  );

  return (
    <div className="vignette relative min-h-dvh overflow-x-hidden bg-void">
      <div className="grid-floor pointer-events-none absolute inset-0 opacity-40" />
      <FxCanvas ref={fxRef} />

      {/* floating score text */}
      <div className="pointer-events-none fixed inset-0 z-[55]">
        {floaters.map((f) => (
          <div
            key={f.id}
            className="anim-float-up absolute font-mono text-xl font-bold"
            style={{ left: f.x, top: f.y, color: f.color, textShadow: `0 0 18px ${f.color}` }}
          >
            {f.text}
            {f.sub && <span className="ml-1 text-sm">{f.sub}</span>}
          </div>
        ))}
      </div>

      {/* banner */}
      {banner && (
        <div className="pointer-events-none fixed inset-x-0 top-24 z-[56] flex justify-center">
          <div
            key={banner.id}
            className="anim-pop-fast rounded-full border px-5 py-2 font-mono text-sm font-bold tracking-[0.2em]"
            style={{
              color: banner.color,
              borderColor: `${banner.color}55`,
              background: `${banner.color}18`,
              textShadow: `0 0 20px ${banner.color}`,
            }}
          >
            {banner.text}
          </div>
        </div>
      )}

      <div ref={shakeElRef} className="relative z-10 will-change-transform">
        {screen === "menu" && (
          <MenuScreen
            difficulties={DIFFICULTIES}
            difficulty={difficulty}
            onDifficulty={(d) => {
              setDifficulty(d);
              play("select");
            }}
            onStart={() => startRun()}
            scores={scores}
          />
        )}

        {screen === "playing" && (
          <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col gap-2.5 px-3 py-3">
            <Hud
              lives={run.lives}
              maxLives={difficulty.lives}
              score={run.score}
              combo={run.combo}
              multiplier={multiplier}
              stage={run.stage}
              qIndex={run.qIndex}
              deckLen={run.deck.length}
              timerRef={timerBarRef}
              onPause={pauseGame}
              onToggleMute={toggleMute}
              muted={muted}
            />

            <div className="min-h-0 shrink-0">
              <CodePanel
                question={run.question}
                revealed={run.phase === "reveal"}
                correct={run.result === "correct"}
              />
            </div>

            <OptionGrid
              options={run.options}
              picked={run.picked}
              revealed={run.phase === "reveal"}
              selected={selected}
              onPick={(i, rect) => answer(i, rect)}
              registerRef={registerOption}
            />

            <div className="mt-auto flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2">
              <Runner mood={runnerMood} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between font-mono text-[9.5px] tracking-[0.2em] text-slate-500">
                  <span>PROGRESS</span>
                  <span>
                    {Math.min(run.qIndex + 1, run.deck.length)}/{run.deck.length}
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-neon to-violet transition-[width] duration-300 ease-out"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
              <span className="hidden font-mono text-[10px] tracking-widest text-slate-600 sm:block">
                {hint}
              </span>
            </div>
          </div>
        )}

        {screen === "paused" && (
          <PauseOverlay
            onResume={resumeGame}
            onRestart={() => startRun()}
            onMenu={goMenu}
            muted={muted}
            onToggleMute={toggleMute}
          />
        )}

        {screen === "stage" && (
          <StageClearOverlay
            stage={run.stage}
            bonus={stageBonus}
            score={run.score}
            onContinue={nextStage}
          />
        )}

        {screen === "gameover" && (
          <GameOverScreen
            score={run.score}
            stage={run.stage}
            bestCombo={run.bestCombo}
            correct={run.correctCount}
            total={run.totalCount}
            isBest={isBest}
            onSave={handleSave}
            onRetry={() => startRun()}
            onMenu={goMenu}
            onShowBoard={() => setShowBoard(true)}
          />
        )}
      </div>

      <Modal open={showBoard} onClose={() => setShowBoard(false)} title="LEADERBOARD">
        <Leaderboard scores={scores} />
      </Modal>
    </div>
  );
}
