export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  stage: number;
  bestCombo: number;
  correct: number;
  total: number;
  date: string;
}

const KEY = "byte-runner.scores.v1";
const MAX = 10;

export function loadScores(): ScoreEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as ScoreEntry[];
  } catch {
    return [];
  }
}

export function saveScore(entry: Omit<ScoreEntry, "id" | "date">): ScoreEntry[] {
  const withMeta: ScoreEntry = {
    ...entry,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    date: new Date().toISOString(),
  };
  const next = [...loadScores(), withMeta]
    .sort((a, b) => b.score - a.score || b.stage - a.stage)
    .slice(0, MAX);
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable — keep the run in memory only */
  }
  return next;
}

export function clearScores() {
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
