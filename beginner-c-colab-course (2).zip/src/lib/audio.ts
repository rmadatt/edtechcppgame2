type SfxName =
  | "select"
  | "correct"
  | "wrong"
  | "tick"
  | "stage"
  | "gameover"
  | "start"
  | "combo"
  | "countdown";

let ctx: AudioContext | null = null;
let muted = false;
let ready = false;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new Ctor();
    }
    if (ctx.state === "suspended") void ctx.resume();
    ready = true;
    return ctx;
  } catch {
    return null;
  }
}

export function unlockAudio() {
  ac();
}

export function setMuted(v: boolean) {
  muted = v;
}

export function isMuted() {
  return muted;
}

function tone(
  freq: number,
  start: number,
  dur: number,
  type: OscillatorType,
  vol: number,
  endFreq?: number,
) {
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + start;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (endFreq !== undefined) osc.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), t0 + dur);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain);
  gain.connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.03);
}

function noise(start: number, dur: number, vol: number) {
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + start;
  const frames = Math.floor(c.sampleRate * dur);
  const buffer = c.createBuffer(1, frames, c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < frames; i++) {
    data[i] = (Math.random() * 2 - 1) * (1 - i / frames);
  }
  const src = c.createBufferSource();
  src.buffer = buffer;
  const gain = c.createGain();
  gain.gain.setValueAtTime(vol, t0);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  const filter = c.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = 900;
  src.connect(filter);
  filter.connect(gain);
  gain.connect(c.destination);
  src.start(t0);
}

export function play(name: SfxName, pitch = 0) {
  if (muted) return;
  if (!ready) ac();
  switch (name) {
    case "select":
      tone(520, 0, 0.06, "square", 0.05);
      break;
    case "tick":
      tone(900, 0, 0.04, "square", 0.035);
      break;
    case "countdown":
      tone(760, 0, 0.09, "triangle", 0.09);
      break;
    case "correct": {
      const base = 620 * Math.pow(1.06, Math.min(pitch, 8));
      tone(base, 0, 0.09, "square", 0.075);
      tone(base * 1.5, 0.07, 0.16, "square", 0.06);
      tone(base * 2, 0.14, 0.2, "triangle", 0.045);
      break;
    }
    case "combo":
      tone(700 + pitch * 90, 0, 0.1, "sawtooth", 0.05, 1400 + pitch * 140);
      break;
    case "wrong":
      tone(220, 0, 0.22, "sawtooth", 0.08, 70);
      noise(0, 0.18, 0.05);
      break;
    case "stage":
      [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.09, 0.24, "square", 0.055));
      break;
    case "start":
      [392, 523, 659].forEach((f, i) => tone(f, i * 0.07, 0.18, "triangle", 0.06));
      break;
    case "gameover":
      [523, 440, 349, 262].forEach((f, i) => tone(f, i * 0.13, 0.32, "sawtooth", 0.05));
      break;
  }
}
