import type { ReactNode } from "react";

const KEYWORDS = new Set([
  "if",
  "else",
  "for",
  "while",
  "do",
  "return",
  "break",
  "continue",
  "const",
  "class",
  "struct",
  "public",
  "private",
  "protected",
  "using",
  "namespace",
  "true",
  "false",
  "new",
  "delete",
  "sizeof",
  "auto",
  "switch",
  "case",
  "default",
  "include",
  "main",
  "std",
  "cin",
  "cout",
  "cerr",
  "endl",
  "getline",
  "boolalpha",
  "vector",
  "string",
  "and",
  "or",
  "not",
]);

const TYPES = new Set([
  "int",
  "double",
  "float",
  "char",
  "bool",
  "void",
  "long",
  "short",
  "unsigned",
  "size_t",
]);

const TOKEN_RE =
  /(\/\/[^\n]*)|("(?:\\.|[^"\\])*")|('(?:\\.|[^'\\])*')|(#\s*\w+)|(<[A-Za-z_][A-Za-z0-9_]*>)|(\b\d+(?:\.\d+)?\b)|(___)|([A-Za-z_]\w*)|(\s+)|([^\s])/g;

const CLR = {
  comment: "#5b6b8c",
  string: "#fbbf24",
  pre: "#f472b6",
  number: "#34d399",
  keyword: "#22d3ee",
  type: "#a78bfa",
  fn: "#7dd3fc",
  plain: "#c7d5ee",
};

function classifyIdent(word: string, src: string, endIndex: number): string {
  if (KEYWORDS.has(word)) return CLR.keyword;
  if (TYPES.has(word)) return CLR.type;
  const after = src.slice(endIndex).match(/^\s*(.)/);
  if (after && after[1] === "(") return CLR.fn;
  return CLR.plain;
}

/** Tokenize a snippet of C++ into coloured spans. */
export function highlight(code: string): ReactNode[] {
  const out: ReactNode[] = [];
  let key = 0;
  let last = 0;
  TOKEN_RE.lastIndex = 0;
  let m: RegExpExecArray | null;
  while ((m = TOKEN_RE.exec(code)) !== null) {
    const [full, comment, str, chr, pre, header, num, blank, ident] = m;
    if (m.index > last) {
      out.push(
        <span key={key++} style={{ color: CLR.plain }}>
          {code.slice(last, m.index)}
        </span>,
      );
    }
    if (comment) {
      out.push(
        <span key={key++} style={{ color: CLR.comment, fontStyle: "italic" }}>
          {comment}
        </span>,
      );
    } else if (str || chr) {
      out.push(
        <span key={key++} style={{ color: CLR.string }}>
          {full}
        </span>,
      );
    } else if (pre || header) {
      out.push(
        <span key={key++} style={{ color: CLR.pre }}>
          {full}
        </span>,
      );
    } else if (num) {
      out.push(
        <span key={key++} style={{ color: CLR.number }}>
          {full}
        </span>,
      );
    } else if (blank) {
      out.push(
        <span
          key={key++}
          className="inline-block min-w-[3.2rem] -translate-y-px rounded-[4px] border-b-2 border-dashed border-amber-300/80 bg-amber-300/10 px-1 text-amber-200"
        >
          {"\u00a0\u00a0\u00a0"}
        </span>,
      );
    } else if (ident) {
      out.push(
        <span key={key++} style={{ color: classifyIdent(ident, code, m.index + full.length) }}>
          {full}
        </span>,
      );
    } else {
      out.push(
        <span key={key++} style={{ color: CLR.plain }}>
          {full}
        </span>,
      );
    }
    last = m.index + full.length;
  }
  if (last < code.length) {
    out.push(
      <span key={key++} style={{ color: CLR.plain }}>
        {code.slice(last)}
      </span>,
    );
  }
  return out;
}
