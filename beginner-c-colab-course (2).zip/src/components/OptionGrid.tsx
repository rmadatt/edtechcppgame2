import { useEffect, useRef } from "react";
import type { Option } from "../game/engine";

interface Props {
  options: Option[];
  picked: number | null;
  revealed: boolean;
  selected: number;
  onPick: (index: number, rect: DOMRect) => void;
  registerRef: (index: number, el: HTMLButtonElement | null) => void;
}

const KEYS = ["1", "2", "3", "4"];
const LETTERS = ["A", "B", "C", "D"];

export function OptionGrid({ options, picked, revealed, selected, onPick, registerRef }: Props) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    refs.current.forEach((el, i) => registerRef(i, el));
  }, [options, registerRef]);

  return (
    <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
      {options.map((opt, i) => {
        const isPicked = picked === i;
        const isCorrect = opt.correct;
        const showCorrect = revealed && isCorrect;
        const showWrong = revealed && isPicked && !isCorrect;

        let tone =
          "border-white/10 bg-white/[0.035] hover:border-neon/50 hover:bg-neon/[0.07] active:scale-[0.985]";
        if (selected === i && !revealed) tone = "border-neon/70 bg-neon/10 glow-neon";
        if (showCorrect) tone = "border-mint/80 bg-mint/15 shadow-[0_0_34px_-6px_rgba(52,211,153,.75)]";
        if (showWrong) tone = "border-rose/80 bg-rose/15 shadow-[0_0_34px_-6px_rgba(251,113,133,.75)]";
        if (revealed && !showCorrect && !showWrong) tone = "border-white/5 bg-white/[0.02] opacity-40";

        return (
          <button
            key={i}
            type="button"
            ref={(el) => {
              refs.current[i] = el;
              registerRef(i, el);
            }}
            onClick={() => {
              const el = refs.current[i];
              if (!el) return;
              onPick(i, el.getBoundingClientRect());
            }}
            disabled={revealed}
            className={`group relative flex touch-manipulation items-center gap-2 overflow-hidden rounded-xl border px-2.5 py-2.5 text-left transition-all duration-150 sm:gap-3 sm:px-4 sm:py-3.5 ${tone} ${
              showWrong ? "anim-stumble" : ""
            } ${showCorrect ? "anim-pop-fast" : ""}`}
          >
            <span
              className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md font-mono text-[11px] font-bold transition-colors sm:h-7 sm:w-7 sm:text-[12px] ${
                showCorrect
                  ? "bg-mint/25 text-mint"
                  : showWrong
                    ? "bg-rose/25 text-rose"
                    : selected === i && !revealed
                      ? "bg-neon/25 text-neon"
                      : "bg-white/[0.06] text-slate-400 group-hover:text-neon"
              }`}
            >
              {KEYS[i]}
            </span>

            <span
              className={`flex-1 font-mono text-[11.5px] leading-snug break-words sm:text-[13.5px] ${
                showCorrect ? "text-mint" : showWrong ? "text-rose" : "text-slate-100"
              }`}
            >
              {opt.text}
            </span>

            <span className="hidden shrink-0 font-mono text-[10px] tracking-widest text-slate-500 sm:block">
              {LETTERS[i]}
            </span>
          </button>
        );
      })}
    </div>
  );
}
