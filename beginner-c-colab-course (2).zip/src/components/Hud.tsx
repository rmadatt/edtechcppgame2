import type { RefObject } from "react";

interface Props {
  lives: number;
  maxLives: number;
  score: number;
  combo: number;
  multiplier: number;
  stage: number;
  qIndex: number;
  deckLen: number;
  timerRef: RefObject<HTMLDivElement | null>;
  onPause: () => void;
  onToggleMute: () => void;
  muted: boolean;
}

function Heart({ alive }: { alive: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className={`h-4 w-4 ${alive ? "" : "opacity-25"}`}>
      <path
        d="M12 21s-7.5-4.7-9.4-9A5.2 5.2 0 0 1 12 5.6 5.2 5.2 0 0 1 21.4 12c-1.9 4.3-9.4 9-9.4 9z"
        fill={alive ? "#fb7185" : "#475569"}
        stroke={alive ? "#fda4af" : "#64748b"}
        strokeWidth="1.2"
      />
    </svg>
  );
}

export function Hud({
  lives,
  maxLives,
  score,
  combo,
  multiplier,
  stage,
  qIndex,
  deckLen,
  timerRef,
  onPause,
  onToggleMute,
  muted,
}: Props) {
  return (
    <div className="glass rounded-2xl px-3 py-2.5 sm:px-4 sm:py-3">
      <div className="flex items-center gap-2.5 sm:gap-4">
        <div className="flex items-center gap-1">
          {Array.from({ length: maxLives }).map((_, i) => (
            <Heart key={i} alive={i < lives} />
          ))}
        </div>

        <div className="hidden h-7 w-px bg-white/10 sm:block" />

        <div className="flex items-baseline gap-1.5">
          <span className="text-[10px] font-semibold tracking-[0.18em] text-slate-500">STAGE</span>
          <span className="font-mono text-sm font-bold text-neon">{stage}</span>
        </div>

        <div className="hidden items-baseline gap-1.5 sm:flex">
          <span className="text-[10px] font-semibold tracking-[0.18em] text-slate-500">Q</span>
          <span className="font-mono text-sm font-bold text-slate-300">
            {qIndex + 1}
            <span className="text-slate-600">/{deckLen}</span>
          </span>
        </div>

        <div className="ml-auto flex items-center gap-3">
          {combo > 0 && (
            <div
              className={`flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[11px] font-bold ${
                multiplier > 1
                  ? "anim-pop-fast border-punch/50 bg-punch/15 text-punch"
                  : "border-white/10 bg-white/5 text-slate-400"
              }`}
            >
              <span className="text-[9px] tracking-widest opacity-70">COMBO</span>
              {combo}
              {multiplier > 1 && <span className="ml-0.5 text-[12px]">x{multiplier}</span>}
            </div>
          )}

          <div className="text-right">
            <div className="text-[9px] font-semibold tracking-[0.18em] text-slate-500">SCORE</div>
            <div className="font-mono text-sm font-bold text-gold text-glow-gold sm:text-base">
              {score.toLocaleString()}
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? "Unmute" : "Mute"}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-neon/50 hover:text-neon"
          >
            {muted ? (
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 5 6 9H2v6h4l5 4z" strokeLinejoin="round" />
                <path d="m22 9-6 6M16 9l6 6" strokeLinecap="round" />
              </svg>
            ) : (
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 5 6 9H2v6h4l5 4z" strokeLinejoin="round" />
                <path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" strokeLinecap="round" />
              </svg>
            )}
          </button>

          <button
            type="button"
            onClick={onPause}
            aria-label="Pause"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-neon/50 hover:text-neon"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
              <rect x="6" y="5" width="4" height="14" rx="1" />
              <rect x="14" y="5" width="4" height="14" rx="1" />
            </svg>
          </button>
        </div>
      </div>

      <div className="mt-2.5 flex items-center gap-2">
        <span className="font-mono text-[9px] tracking-[0.2em] text-slate-600">COMPILE</span>
        <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
          <div
            ref={timerRef}
            className="h-full rounded-full bg-mint"
            style={{ width: "100%", background: "#34d399", boxShadow: "0 0 14px -2px #34d399" }}
          />
        </div>
      </div>
    </div>
  );
}
