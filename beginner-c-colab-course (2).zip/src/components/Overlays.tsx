interface PauseProps {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  muted: boolean;
  onToggleMute: () => void;
}

export function PauseOverlay({
  onResume,
  onRestart,
  onMenu,
  muted,
  onToggleMute,
}: PauseProps) {
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center bg-void/80 px-4 backdrop-blur-sm">
      <div className="glass anim-pop w-full max-w-sm overflow-hidden rounded-3xl">
        <div className="border-b border-white/10 px-6 py-5 text-center">
          <div className="font-mono text-[10px] tracking-[0.3em] text-neon">BUILD HALTED</div>
          <h2 className="mt-1 text-3xl font-bold tracking-tight text-white">PAUSED</h2>
        </div>
        <div className="space-y-2 p-5">
          <button
            type="button"
            onClick={onResume}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon to-violet px-5 py-3.5 font-bold text-void transition-transform active:scale-[0.98]"
          >
            RESUME
            <span className="keycap border-void/30 bg-void/15 text-void">P</span>
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/12 bg-white/[0.04] px-5 py-3.5 font-mono text-[12px] font-bold tracking-widest text-slate-200 transition-colors hover:border-neon/50 hover:text-neon"
          >
            RESTART RUN
            <span className="keycap">R</span>
          </button>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              className="flex-1 rounded-xl border border-white/12 bg-white/[0.03] px-4 py-2.5 font-mono text-[11px] tracking-widest text-slate-400 transition-colors hover:text-neon"
            >
              {muted ? "SOUND OFF" : "SOUND ON"}
            </button>
            <button
              type="button"
              onClick={onMenu}
              className="flex-1 rounded-xl border border-white/12 bg-white/[0.03] px-4 py-2.5 font-mono text-[11px] tracking-widest text-slate-400 transition-colors hover:text-neon"
            >
              QUIT
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface StageClearProps {
  stage: number;
  bonus: number;
  score: number;
  onContinue: () => void;
}

export function StageClearOverlay({ stage, bonus, score, onContinue }: StageClearProps) {
  return (
    <div className="fixed inset-0 z-[65] flex items-center justify-center bg-void/75 px-4 backdrop-blur-sm">
      <div className="glass anim-pop w-full max-w-sm overflow-hidden rounded-3xl text-center">
        <div className="relative overflow-hidden bg-gradient-to-b from-mint/20 to-transparent px-6 py-6">
          <div className="font-mono text-[10px] tracking-[0.3em] text-mint">BUILD SUCCESSFUL</div>
          <h2 className="mt-1 text-3xl font-bold tracking-tight text-white">STAGE {stage} CLEAR</h2>
        </div>
        <div className="px-6 pb-6">
          <div className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3">
            <div className="text-[10px] tracking-[0.25em] text-slate-500">CLEAR BONUS</div>
            <div className="font-mono text-3xl font-bold text-gold text-glow-gold">
              +{bonus.toLocaleString()}
            </div>
          </div>
          <div className="mt-3 font-mono text-[12px] text-slate-400">
            TOTAL {score.toLocaleString()}
          </div>
          <button
            type="button"
            onClick={onContinue}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon to-violet px-5 py-3.5 font-bold text-void transition-transform active:scale-[0.98]"
          >
            NEXT BUILD
            <span className="keycap border-void/30 bg-void/15 text-void">ENTER</span>
          </button>
        </div>
      </div>
    </div>
  );
}
