import { useState } from "react";
import type { Difficulty } from "../data/questions";
import type { ScoreEntry } from "../lib/storage";
import { Leaderboard } from "./Leaderboard";
import { Modal } from "./Modal";

interface Props {
  difficulties: Difficulty[];
  difficulty: Difficulty;
  onDifficulty: (d: Difficulty) => void;
  onStart: () => void;
  scores: ScoreEntry[];
}

const MARQUEE = [
  "#include <iostream>",
  "int main() {",
  "  std::cout << \"Hello, C++!\" << '\\n';",
  "  return 0;",
  "}",
  "g++ -std=c++17 main.cpp -o main && ./main",
  "std::vector<std::string> names",
  "for (const std::string& n : names)",
  "class Dog { std::string name; };",
  "score += askQuestion(q, a);",
];

export function MenuScreen({ difficulties, difficulty, onDifficulty, onStart, scores }: Props) {
  const [howTo, setHowTo] = useState(false);
  const [board, setBoard] = useState(false);
  const best = scores.length ? scores[0].score : 0;

  return (
    <div className="relative z-10 flex min-h-dvh flex-col items-center justify-center px-4 py-10">
      <div className="w-full max-w-2xl text-center">
        <div className="anim-pop-fast inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/10 px-3 py-1 font-mono text-[10px] font-bold tracking-[0.28em] text-neon">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-neon" />
          C++ ARCADE · BEGINNER COURSE
        </div>

        <h1 className="anim-pop mt-5 text-[13vw] leading-[0.85] font-bold tracking-tight text-white sm:text-7xl">
          BYTE
          <span className="bg-gradient-to-br from-neon via-neonsoft to-violet bg-clip-text text-transparent text-glow">
            RUNNER
          </span>
        </h1>

        <p className="anim-pop mx-auto mt-4 max-w-md text-[13.5px] leading-relaxed text-slate-400 sm:text-[15px]">
          Race the compiler. Read the snippet, pick the right line, and ship the build before the
          timer burns out.
        </p>

        {/* difficulty */}
        <div className="anim-pop mt-7">
          <div className="mb-2 font-mono text-[10px] tracking-[0.25em] text-slate-500">
            BUILD PROFILE
          </div>
          <div className="grid grid-cols-3 gap-2">
            {difficulties.map((d) => {
              const active = d.id === difficulty.id;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => onDifficulty(d)}
                  className={`rounded-xl border px-2 py-2.5 transition-all ${
                    active
                      ? "border-neon/70 bg-neon/10 glow-neon"
                      : "border-white/10 bg-white/[0.03] hover:border-white/25"
                  }`}
                >
                  <div
                    className="font-mono text-[12px] font-bold tracking-wide"
                    style={{ color: active ? d.accent : "#cbd5e1" }}
                  >
                    {d.name.toUpperCase()}
                  </div>
                  <div className="mt-0.5 font-mono text-[10px] text-slate-500">
                    {d.timeLimit}s · {d.lives} ♥
                  </div>
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-[11.5px] text-slate-500">{difficulty.blurb}</p>
        </div>

        {/* start */}
        <button
          type="button"
          onClick={onStart}
          className="anim-pop group relative mt-7 inline-flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl bg-gradient-to-r from-neon to-violet px-8 py-4 text-lg font-bold tracking-wide text-void shadow-[0_18px_50px_-18px_rgba(34,211,238,.9)] transition-transform active:scale-[0.98] sm:w-auto"
        >
          <span className="absolute inset-0 -translate-x-full bg-white/30 transition-transform duration-500 group-hover:translate-x-full" />
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
          START RUN
          <span className="keycap border-void/30 bg-void/15 text-void">ENTER</span>
        </button>

        {/* secondary */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={() => setHowTo(true)}
            className="rounded-lg border border-white/10 bg-white/[0.04] px-4 py-2 font-mono text-[11px] tracking-widest text-slate-300 transition-colors hover:border-neon/50 hover:text-neon"
          >
            HOW TO PLAY
          </button>
          <button
            type="button"
            onClick={() => setBoard(true)}
            className="rounded-lg border border-white/10 bg-white/[0.04] px-4 py-2 font-mono text-[11px] tracking-widest text-slate-300 transition-colors hover:border-neon/50 hover:text-neon"
          >
            LEADERBOARD
          </button>
          <div className="rounded-lg border border-gold/25 bg-gold/[0.07] px-4 py-2 font-mono text-[11px] tracking-widest text-gold">
            BEST {best.toLocaleString()}
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px] text-slate-500">
          <span className="flex items-center gap-1.5">
            <span className="keycap">1</span>
            <span className="keycap">2</span>
            <span className="keycap">3</span>
            <span className="keycap">4</span>
            answer
          </span>
          <span className="flex items-center gap-1.5">
            <span className="keycap">P</span>
            pause
          </span>
          <span className="flex items-center gap-1.5">
            <span className="keycap">R</span>
            restart
          </span>
          <span className="hidden sm:inline">touch the cards to play</span>
        </div>
      </div>

      {/* scrolling code strip */}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-0 overflow-hidden border-y border-white/5 bg-black/25 py-2">
        <div className="running-strip flex w-max gap-8 whitespace-nowrap font-mono text-[11px] text-slate-600">
          {[...MARQUEE, ...MARQUEE, ...MARQUEE, ...MARQUEE].map((line, i) => (
            <span key={i}>{line}</span>
          ))}
        </div>
      </div>

      <Modal open={howTo} onClose={() => setHowTo(false)} title="HOW TO PLAY">
        <ul className="space-y-3 text-[13px] leading-relaxed text-slate-300">
          <li className="flex gap-3">
            <span className="keycap shrink-0">1</span>
            <span>
              A C++ snippet appears with a blank or a question. Read it fast — the compile bar is
              your clock.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="keycap shrink-0">2</span>
            <span>
              Pick the right answer with <b className="text-white">1–4</b> or{" "}
              <b className="text-white">A–D</b>, arrow keys + <b className="text-white">Enter</b>,
              or by tapping a card.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="keycap shrink-0">3</span>
            <span>
              Correct answers build a <b className="text-punch">combo</b> (up to x5) and pay a speed
              bonus. Wrong answers cost a heart and reset the combo.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="keycap shrink-0">4</span>
            <span>
              Clear all 8 snippets in a stage to advance the build. Boss snippets pay double.
              Stages get faster every time.
            </span>
          </li>
          <li className="flex gap-3">
            <span className="keycap shrink-0">5</span>
            <span>
              Run out of hearts and the build fails. Your score is saved to the local leaderboard.
            </span>
          </li>
        </ul>
      </Modal>

      <Modal open={board} onClose={() => setBoard(false)} title="LEADERBOARD">
        <Leaderboard scores={scores} />
      </Modal>
    </div>
  );
}
