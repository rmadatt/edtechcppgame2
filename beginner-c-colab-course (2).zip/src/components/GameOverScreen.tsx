import { useState } from "react";

interface Props {
  score: number;
  stage: number;
  bestCombo: number;
  correct: number;
  total: number;
  isBest: boolean;
  onSave: (name: string) => void;
  onRetry: () => void;
  onMenu: () => void;
  onShowBoard: () => void;
}

export function GameOverScreen({
  score,
  stage,
  bestCombo,
  correct,
  total,
  isBest,
  onSave,
  onRetry,
  onMenu,
  onShowBoard,
}: Props) {
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

  const submit = () => {
    const clean = (name.trim() || "PLAYER").toUpperCase().slice(0, 8);
    onSave(clean);
    setSaved(true);
  };

  return (
    <div className="relative z-10 flex min-h-dvh items-center justify-center px-4 py-8">
      <div className="glass anim-pop w-full max-w-lg overflow-hidden rounded-3xl">
        <div className="relative overflow-hidden bg-gradient-to-b from-rose/20 to-transparent px-6 py-6 text-center">
          <div className="font-mono text-[10px] tracking-[0.3em] text-rose">BUILD FAILED</div>
          <h2 className="mt-1 text-4xl font-bold tracking-tight text-white">COMPILE ERROR</h2>
          {isBest && (
            <div className="anim-pop-fast mt-3 inline-block rounded-full border border-gold/50 bg-gold/15 px-3 py-1 font-mono text-[11px] font-bold tracking-widest text-gold text-glow-gold">
              ★ NEW PERSONAL BEST
            </div>
          )}
        </div>

        <div className="px-6 pb-6">
          <div className="text-center">
            <div className="text-[10px] font-semibold tracking-[0.25em] text-slate-500">FINAL SCORE</div>
            <div className="font-mono text-5xl font-bold text-gold text-glow-gold">
              {score.toLocaleString()}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-3 gap-2">
            {[
              { label: "STAGE", value: stage },
              { label: "BEST COMBO", value: `x${bestCombo}` },
              { label: "ACCURACY", value: `${accuracy}%` },
            ].map((s) => (
              <div
                key={s.label}
                className="rounded-xl border border-white/10 bg-white/[0.04] px-2 py-2.5 text-center"
              >
                <div className="font-mono text-[9px] tracking-[0.2em] text-slate-500">{s.label}</div>
                <div className="mt-0.5 font-mono text-lg font-bold text-slate-100">{s.value}</div>
              </div>
            ))}
          </div>

          {!saved ? (
            <div className="mt-5">
              <label className="mb-1.5 block font-mono text-[10px] tracking-[0.25em] text-slate-500">
                SIGN THE BUILD LOG
              </label>
              <div className="flex gap-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value.toUpperCase())}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") submit();
                  }}
                  maxLength={8}
                  autoFocus
                  placeholder="PLAYER"
                  className="w-full rounded-xl border border-white/12 bg-black/40 px-4 py-3 font-mono text-sm font-bold tracking-[0.2em] text-white uppercase outline-none transition-colors placeholder:text-slate-600 focus:border-neon/70 focus:shadow-[0_0_26px_-8px_rgba(34,211,238,.8)]"
                />
                <button
                  type="button"
                  onClick={submit}
                  className="shrink-0 rounded-xl bg-neon px-5 py-3 font-mono text-[11px] font-bold tracking-widest text-void transition-transform active:scale-95"
                >
                  SAVE
                </button>
              </div>
            </div>
          ) : (
            <div className="anim-pop-fast mt-5 rounded-xl border border-mint/30 bg-mint/10 px-4 py-3 text-center font-mono text-[12px] tracking-widest text-mint">
              ✓ SAVED TO LEADERBOARD
            </div>
          )}

          <div className="mt-5 flex gap-2">
            <button
              type="button"
              onClick={onRetry}
              className="group flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon to-violet px-5 py-3.5 font-bold text-void transition-transform active:scale-[0.98]"
            >
              RETRY
              <span className="keycap border-void/30 bg-void/15 text-void">R</span>
            </button>
            <button
              type="button"
              onClick={onMenu}
              className="rounded-xl border border-white/12 bg-white/[0.04] px-5 py-3.5 font-mono text-[11px] font-bold tracking-widest text-slate-300 transition-colors hover:border-neon/50 hover:text-neon"
            >
              MENU
            </button>
          </div>

          <button
            type="button"
            onClick={onShowBoard}
            className="mt-2 w-full rounded-xl border border-white/10 bg-white/[0.03] px-5 py-2.5 font-mono text-[11px] font-bold tracking-widest text-slate-400 transition-colors hover:border-gold/40 hover:text-gold"
          >
            VIEW LEADERBOARD
          </button>
        </div>
      </div>
    </div>
  );
}
