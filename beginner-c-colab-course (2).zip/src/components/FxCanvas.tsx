import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";

export interface FxHandle {
  burst: (
    x: number,
    y: number,
    color: string,
    opts?: { count?: number; power?: number; square?: boolean; spread?: number },
  ) => void;
  ring: (x: number, y: number, color: string, radius?: number) => void;
  wave: (color: string) => void;
  clear: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  square: boolean;
  gravity: number;
  drag: number;
}

interface Ring {
  x: number;
  y: number;
  r: number;
  max: number;
  life: number;
  color: string;
}

interface Wave {
  y: number;
  color: string;
  life: number;
}

interface RainLine {
  text: string;
  x: number;
  y: number;
  speed: number;
  alpha: number;
  size: number;
  color: string;
}

const RAIN_TOKENS = [
  "#include <iostream>",
  "std::cout << answer << '\\n';",
  "int total = 0;",
  "for (int i = 0; i < n; i++)",
  "std::vector<std::string> names",
  "return 0;",
  "bool isRipe = true;",
  "const std::string& name",
  "g++ -std=c++17 main.cpp",
  "double price = 1.25;",
  "while (countdown > 0)",
  "public: void bark()",
  "std::getline(std::cin, r);",
  "class Dog { std::string name; };",
  "score += askQuestion(q, a);",
  "if (temperature >= 30)",
  "total += number;",
  "std::cout << '\\n';",
];

const RAIN_COLORS = ["#1d2a4d", "#233355", "#2a3a5e", "#1a2647"];

function makeRain(w: number, h: number): RainLine[] {
  const lines: RainLine[] = [];
  const count = Math.max(14, Math.round(h / 46));
  for (let i = 0; i < count; i++) {
    lines.push({
      text: RAIN_TOKENS[Math.floor(Math.random() * RAIN_TOKENS.length)],
      x: Math.random() * w,
      y: Math.random() * h,
      speed: 8 + Math.random() * 22,
      alpha: 0.05 + Math.random() * 0.12,
      size: 12 + Math.random() * 5,
      color: RAIN_COLORS[Math.floor(Math.random() * RAIN_COLORS.length)],
    });
  }
  return lines;
}

export const FxCanvas = forwardRef<FxHandle>(function FxCanvas(_props, ref) {
  const bgRef = useRef<HTMLCanvasElement | null>(null);
  const fxRef = useRef<HTMLCanvasElement | null>(null);
  const particles = useRef<Particle[]>([]);
  const rings = useRef<Ring[]>([]);
  const waves = useRef<Wave[]>([]);
  const rain = useRef<RainLine[]>([]);
  const size = useRef({ w: 0, h: 0, dpr: 1 });
  const accent = useRef<string>("#22d3ee");
  const flash = useRef<{ color: string; life: number } | null>(null);

  useImperativeHandle(ref, () => ({
    burst(x, y, color, opts = {}) {
      const count = opts.count ?? 22;
      const power = opts.power ?? 320;
      const spread = opts.spread ?? Math.PI * 2;
      accent.current = color;
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * spread - spread / 2 + (opts.square ? Math.PI / 4 : 0);
        const speed = power * (0.35 + Math.random() * 0.9);
        const life = 0.45 + Math.random() * 0.55;
        particles.current.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 40,
          life,
          max: life,
          size: 2.5 + Math.random() * 4.5,
          color,
          square: opts.square ?? Math.random() > 0.55,
          gravity: 620 + Math.random() * 380,
          drag: 0.86 + Math.random() * 0.1,
        });
      }
      if (particles.current.length > 900) particles.current.splice(0, particles.current.length - 900);
    },
    ring(x, y, color, radius = 120) {
      rings.current.push({ x, y, r: 4, max: radius, life: 0.5, color });
      flash.current = { color, life: 0.28 };
    },
    wave(color) {
      waves.current.push({ y: -40, color, life: 1.1 });
    },
    clear() {
      particles.current = [];
      rings.current = [];
      waves.current = [];
      flash.current = null;
    },
  }));

  useEffect(() => {
    const bg = bgRef.current;
    const fx = fxRef.current;
    if (!bg || !fx) return;
    const bgCtx = bg.getContext("2d");
    const fxCtx = fx.getContext("2d");
    if (!bgCtx || !fxCtx) return;

    let raf = 0;
    let last = performance.now();
    let bgAcc = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = window.innerWidth;
      const h = window.innerHeight;
      size.current = { w, h, dpr };
      for (const c of [bg, fx]) {
        c.width = Math.floor(w * dpr);
        c.height = Math.floor(h * dpr);
        c.style.width = `${w}px`;
        c.style.height = `${h}px`;
      }
      bgCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      fxCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      rain.current = makeRain(w, h);
    };

    resize();
    window.addEventListener("resize", resize);

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const { w, h } = size.current;

      /* ---- background code rain (throttled to ~30fps) ---- */
      bgAcc += dt;
      if (bgAcc >= 1 / 32) {
        bgAcc = 0;
        bgCtx.clearRect(0, 0, w, h);
        bgCtx.font = "13px 'JetBrains Mono', ui-monospace, monospace";
        bgCtx.textBaseline = "top";
        for (const line of rain.current) {
          line.y -= line.speed * dt;
          if (line.y < -30) {
            line.y = h + 20;
            line.x = Math.random() * w;
            line.text = RAIN_TOKENS[Math.floor(Math.random() * RAIN_TOKENS.length)];
          }
          bgCtx.fillStyle = line.color;
          bgCtx.globalAlpha = line.alpha;
          bgCtx.fillText(line.text, line.x, line.y);
        }
        bgCtx.globalAlpha = 1;
      }

      /* ---- particles ---- */
      fxCtx.clearRect(0, 0, w, h);
      fxCtx.globalCompositeOperation = "lighter";

      const ps = particles.current;
      for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.life -= dt;
        if (p.life <= 0) {
          ps.splice(i, 1);
          continue;
        }
        p.vy += p.gravity * dt;
        p.vx *= Math.pow(p.drag, dt * 60);
        p.vy *= Math.pow(p.drag, dt * 60);
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        const t = p.life / p.max;
        fxCtx.globalAlpha = Math.min(1, t * 1.4);
        fxCtx.fillStyle = p.color;
        if (p.square) {
          fxCtx.save();
          fxCtx.translate(p.x, p.y);
          fxCtx.rotate((p.max - p.life) * 6);
          fxCtx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          fxCtx.restore();
        } else {
          fxCtx.beginPath();
          fxCtx.arc(p.x, p.y, p.size * (0.5 + t * 0.6), 0, Math.PI * 2);
          fxCtx.fill();
        }
      }

      /* ---- rings ---- */
      const rs = rings.current;
      for (let i = rs.length - 1; i >= 0; i--) {
        const r = rs[i];
        r.life -= dt;
        if (r.life <= 0) {
          rs.splice(i, 1);
          continue;
        }
        const t = 1 - r.life / 0.5;
        const radius = r.r + (r.max - r.r) * (1 - Math.pow(1 - t, 3));
        fxCtx.globalAlpha = (1 - t) * 0.8;
        fxCtx.strokeStyle = r.color;
        fxCtx.lineWidth = Math.max(1, 6 * (1 - t));
        fxCtx.beginPath();
        fxCtx.arc(r.x, r.y, radius, 0, Math.PI * 2);
        fxCtx.stroke();
      }

      /* ---- compile waves ---- */
      const ws = waves.current;
      for (let i = ws.length - 1; i >= 0; i--) {
        const wv = ws[i];
        wv.life -= dt;
        if (wv.life <= 0) {
          ws.splice(i, 1);
          continue;
        }
        wv.y += (h / 1.1) * dt;
        const grad = fxCtx.createLinearGradient(0, wv.y - 60, 0, wv.y + 60);
        grad.addColorStop(0, "rgba(0,0,0,0)");
        grad.addColorStop(0.5, wv.color);
        grad.addColorStop(1, "rgba(0,0,0,0)");
        fxCtx.globalAlpha = Math.min(0.75, wv.life);
        fxCtx.fillStyle = grad;
        fxCtx.fillRect(0, wv.y - 60, w, 120);
      }

      /* ---- screen flash ---- */
      if (flash.current) {
        flash.current.life -= dt;
        if (flash.current.life <= 0) flash.current = null;
        else {
          fxCtx.globalAlpha = flash.current.life * 0.5;
          fxCtx.fillStyle = flash.current.color;
          fxCtx.fillRect(0, 0, w, h);
        }
      }

      fxCtx.globalAlpha = 1;
      fxCtx.globalCompositeOperation = "source-over";
      raf = requestAnimationFrame(frame);
    };

    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <>
      <canvas ref={bgRef} className="pointer-events-none fixed inset-0 z-0" aria-hidden="true" />
      <canvas ref={fxRef} className="pointer-events-none fixed inset-0 z-50" aria-hidden="true" />
    </>
  );
});
