interface RunnerProps {
  mood: "idle" | "happy" | "oops";
}

export function Runner({ mood }: RunnerProps) {
  const anim = mood === "happy" ? "anim-hop" : mood === "oops" ? "anim-stumble" : "anim-bob";
  const eye = mood === "happy" ? "#34d399" : mood === "oops" ? "#fb7185" : "#22d3ee";

  return (
    <svg
      viewBox="0 0 44 48"
      className={`h-11 w-11 shrink-0 ${anim}`}
      style={{ animationIterationCount: mood === "idle" ? "infinite" : "1" }}
      aria-hidden="true"
    >
      <g stroke="#67e8f9" strokeWidth="2" fill="none" strokeLinecap="round">
        <path d="M22 4v6" opacity="0.8" />
        <circle cx="22" cy="3" r="2.6" fill={eye} stroke="none" />
      </g>
      <rect x="4" y="10" width="36" height="26" rx="8" fill="#0b1124" stroke="#22d3ee" strokeWidth="2" />
      <rect x="9" y="15" width="26" height="12" rx="5" fill="#050a18" stroke="#1e3a5f" strokeWidth="1.5" />
      <circle cx="16" cy="21" r="3" fill={eye} />
      <circle cx="28" cy="21" r="3" fill={eye} />
      <path
        d={mood === "oops" ? "M16 33 Q22 28 28 33" : mood === "happy" ? "M16 31 Q22 36 28 31" : "M17 32 h10"}
        stroke={eye}
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
      />
      <g stroke="#a78bfa" strokeWidth="2.4" strokeLinecap="round">
        <path d="M13 36v6" />
        <path d="M31 36v6" />
      </g>
      <g stroke="#22d3ee" strokeWidth="2.4" strokeLinecap="round">
        <path d="M9 42h8" />
        <path d="M27 42h8" />
      </g>
    </svg>
  );
}
