import type { ReactNode } from "react";

interface Props {
  open: boolean;
  onClose?: () => void;
  title?: string;
  children: ReactNode;
  maxWidth?: string;
}

export function Modal({ open, onClose, title, children, maxWidth = "max-w-lg" }: Props) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-void/80 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className={`anim-pop glass relative w-full ${maxWidth} overflow-hidden rounded-3xl`}
        role="dialog"
        aria-modal="true"
      >
        {title && (
          <div className="flex items-center justify-between border-b border-white/10 px-5 py-3.5">
            <h3 className="font-mono text-sm font-bold tracking-[0.2em] text-neon text-glow">
              {title}
            </h3>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="rounded-md px-2 py-1 text-slate-500 transition-colors hover:text-rose"
                aria-label="Close"
              >
                ✕
              </button>
            )}
          </div>
        )}
        <div className="max-h-[75dvh] overflow-y-auto px-5 py-4">{children}</div>
      </div>
    </div>
  );
}
