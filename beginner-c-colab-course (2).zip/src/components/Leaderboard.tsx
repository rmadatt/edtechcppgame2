import type { ScoreEntry } from "../lib/storage";

interface Props {
  scores: ScoreEntry[];
  compact?: boolean;
}

const MEDAL = ["#fbbf24", "#cbd5e1", "#d97706"];

export function Leaderboard({ scores, compact }: Props) {
  if (scores.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-slate-500">
        No runs recorded yet. Be the first to ship a build.
      </p>
    );
  }

  return (
    <ol className="space-y-1.5">
      {scores.map((s, i) => (
        <li
          key={s.id}
          className="flex items-center gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] px-3 py-2"
        >
          <span
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg font-mono text-[12px] font-bold"
            style={{
              color: i < 3 ? MEDAL[i] : "#64748b",
              background: i < 3 ? `${MEDAL[i]}1f` : "rgba(255,255,255,.04)",
            }}
          >
            {i + 1}
          </span>
          <span className="min-w-0 flex-1 truncate font-mono text-[13px] font-semibold tracking-wide text-slate-100">
            {s.name}
          </span>
          {!compact && (
            <span className="hidden font-mono text-[11px] text-slate-500 sm:block">
              ST{s.stage} · {s.correct}/{s.total}
            </span>
          )}
          <span className="font-mono text-sm font-bold text-gold text-glow-gold">
            {s.score.toLocaleString()}
          </span>
        </li>
      ))}
    </ol>
  );
}
