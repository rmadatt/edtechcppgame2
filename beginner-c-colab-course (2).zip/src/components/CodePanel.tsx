import type { Question } from "../data/questions";
import { highlight } from "../lib/highlight";

interface Props {
  question: Question;
  revealed: boolean;
  correct: boolean;
}

export function CodePanel({ question, revealed, correct }: Props) {
  const lines = (question.code ?? "").split("\n");
  const match = question.lesson.match(/Lesson (\d+)/);
  const fileName = match
    ? `lesson${match[1].padStart(2, "0")}.cpp`
    : question.lesson.startsWith("Set up")
      ? "setup.sh"
      : "build-notes.md";

  return (
    <div
      className={`glass anim-pop-fast relative overflow-hidden rounded-2xl transition-colors duration-200 ${
        revealed
          ? correct
            ? "border-mint/60 shadow-[0_0_40px_-16px_rgba(52,211,153,.9)]"
            : "border-rose/60 shadow-[0_0_40px_-16px_rgba(251,113,133,.9)]"
          : ""
      }`}
    >
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-2.5">
        <span className="flex gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-rose/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-gold/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-mint/70" />
        </span>
        <span className="font-mono text-[11px] tracking-wide text-slate-400">{fileName}</span>
        {question.boss && (
          <span className="rounded-full border border-punch/40 bg-punch/15 px-2 py-0.5 font-mono text-[10px] font-bold tracking-widest text-punch">
            BOSS
          </span>
        )}
        {question.kind === "output" && (
          <span className="rounded-full border border-neon/40 bg-neon/10 px-2 py-0.5 font-mono text-[10px] font-bold tracking-widest text-neon">
            OUTPUT
          </span>
        )}
        <span className="ml-auto hidden text-[11px] text-slate-400 sm:block">{question.lesson}</span>
      </div>

      {lines.length > 0 ? (
        <div className="no-scrollbar max-h-[23vh] overflow-auto px-4 py-3 sm:max-h-[30vh]">
          <pre className="font-mono text-[13px] leading-[1.75] sm:text-[14px]">
            {lines.map((line, i) => (
              <div key={i} className="flex gap-4">
                <span className="w-4 shrink-0 select-none text-right text-[11px] leading-[1.95] text-slate-600">
                  {i + 1}
                </span>
                <code className="whitespace-pre">{highlight(line)}</code>
              </div>
            ))}
          </pre>
        </div>
      ) : null}

      <div className="border-t border-white/10 px-4 py-3 text-[13.5px] font-medium leading-snug text-slate-100 sm:text-[15px]">
        {question.prompt}
      </div>

      {revealed && (
        <div
          className={`anim-pop-fast flex items-start gap-2.5 border-t px-4 py-3 text-[12.5px] leading-snug ${
            correct
              ? "border-mint/30 bg-mint/10 text-mint"
              : "border-rose/30 bg-rose/10 text-rose"
          }`}
        >
          <span className="mt-0.5 font-mono text-xs">{correct ? "✓" : "✕"}</span>
          <span className="text-slate-200/90">{question.explain}</span>
        </div>
      )}
    </div>
  );
}
